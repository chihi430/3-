package com.study.android.pchsns.models;

import android.util.Log;

public class UserModel {

    private String userid;
    private String uid;
    private String usernm;
    private String token;
    private String userphoto;
    private String usermsg;
    public String getUserid() {
        return userid;
    }

    public void model(String userid, String usernm) {
        this.userid = userid;
        this.usernm = usernm;
    }
    public void photo(String userphoto){
        this.userphoto = userphoto;
    }

    public void setUserid(String userid) {
        this.userid = userid;
    }

    public String getUid() {
        return uid;
    }

    public void setUid(String uid) { this.uid = uid; }

    public String getUsernm() {
        return usernm;
    }

    public void setUsernm(String usernm) {
        this.usernm = usernm;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public String getUserphoto() {
        return userphoto;
    }

    public void setUserphoto(String userphoto) {
        this.userphoto = userphoto;
    }

    public String getUsermsg() {
        return usermsg;
    }

    public void setUsermsg(String usermsg) {
        this.usermsg = usermsg;
    }
}
